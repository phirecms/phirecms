<?php

return [
    APP_URI . '/test[/]' => [
        'controller' => 'Test\Controller\IndexController',
        'action'     => 'index'
    ],
    APP_URI . '/test/config[/]' => [
        'controller' => 'Test\Controller\IndexController',
        'action'     => 'config'
    ]
];
