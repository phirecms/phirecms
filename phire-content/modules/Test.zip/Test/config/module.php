<?php
/**
 * Module Name: Test Module
 * Author: Nick Sagona
 * Description: This is a test module for Phire CMS 2
 * Version: 1.0
 */
return [
    'Test' => [
        'namespace'  => 'Test\\',
        'src'        => __DIR__ . '/../src',
        'routes'     => include 'routes.php',
        'install'    => function($services){
            touch($_SERVER['DOCUMENT_ROOT'] . BASE_PATH . CONTENT_PATH . '/test.txt');
        },
        'uninstall'  => function($services){
            unlink($_SERVER['DOCUMENT_ROOT'] . BASE_PATH . CONTENT_PATH . '/test.txt');
        },
        'services'   => [
            'call' => 'Test\Model\Test'
        ],
        'events'     => [
            [
                'name'   => 'app.route.pre',
                'action' => function($application) {
                    echo 'Pre-route from Test Module';
                }
            ]
        ],
        'nav.phire'  => [
            [
                'name' => 'Test',
                'href' => BASE_PATH . APP_URI . '/test',
                'acl'  => [
                    'resource' => BASE_PATH . APP_URI . '/test[/]'
                ]
            ]
        ],
        'nav.module' => [
            [
                'name' => 'Config',
                'href' => BASE_PATH . APP_URI . '/test/config',
                'acl'  => [
                    'resource' => BASE_PATH . APP_URI . '/test/config[/]'
                ]
            ]
        ]
    ]
];