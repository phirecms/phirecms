<?php

namespace Test\Model;

use Phire\Model\AbstractModel;

class Test extends AbstractModel
{

}
