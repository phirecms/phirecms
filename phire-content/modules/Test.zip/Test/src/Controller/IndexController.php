<?php

namespace Test\Controller;

use Pop\Controller\Controller;

class IndexController extends Controller
{

    public function index()
    {
        echo 'Test module!';
    }

    public function config()
    {
        echo 'Test module config!';
    }

}
