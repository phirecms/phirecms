DROP TABLE IF EXISTS `[{prefix}]test_table`;
CREATE TABLE IF NOT EXISTS `[{prefix}]test_table` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `somename` int(16),
  `sometext` varchar(255),
  `somedesc` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10001 ;

