<?php

/**
 * Set the location of the system bootstrap file
 * (open_base restrictions must be off)
 */
try {
    require_once '/path/to/the/system/basepath/bootstrap.php';
    $project->load($autoloader, true)
            ->run();
} catch (Exception $e) {
    echo $e->getMessage();
}
